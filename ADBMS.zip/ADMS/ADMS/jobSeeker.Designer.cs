﻿namespace ADMS
{
    partial class jobSeeker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(jobSeeker));
            this.signUpPanelAll = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textPath = new System.Windows.Forms.TextBox();
            this.imageButton = new MetroFramework.Controls.MetroButton();
            this.skillBox = new MetroFramework.Controls.MetroTextBox();
            this.skillLabel = new MetroFramework.Controls.MetroLabel();
            this.eduBox = new MetroFramework.Controls.MetroTextBox();
            this.eduLabel = new MetroFramework.Controls.MetroLabel();
            this.dbLabel = new MetroFramework.Controls.MetroLabel();
            this.repassBox = new MetroFramework.Controls.MetroTextBox();
            this.repassLabel = new MetroFramework.Controls.MetroLabel();
            this.passBox = new MetroFramework.Controls.MetroTextBox();
            this.passLabel = new MetroFramework.Controls.MetroLabel();
            this.addressBox = new MetroFramework.Controls.MetroTextBox();
            this.addLebel = new MetroFramework.Controls.MetroLabel();
            this.phoneBox = new MetroFramework.Controls.MetroTextBox();
            this.phoneLabel = new MetroFramework.Controls.MetroLabel();
            this.emailBox = new MetroFramework.Controls.MetroTextBox();
            this.emailLabel = new MetroFramework.Controls.MetroLabel();
            this.IdBox = new MetroFramework.Controls.MetroTextBox();
            this.userIdLebel = new MetroFramework.Controls.MetroLabel();
            this.nameBox = new MetroFramework.Controls.MetroTextBox();
            this.nameLabel = new MetroFramework.Controls.MetroLabel();
            this.signUpButton = new MetroFramework.Controls.MetroButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.signUpPanelAll.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // signUpPanelAll
            // 
            this.signUpPanelAll.Controls.Add(this.dateTimePicker1);
            this.signUpPanelAll.Controls.Add(this.textPath);
            this.signUpPanelAll.Controls.Add(this.imageButton);
            this.signUpPanelAll.Controls.Add(this.skillBox);
            this.signUpPanelAll.Controls.Add(this.skillLabel);
            this.signUpPanelAll.Controls.Add(this.eduBox);
            this.signUpPanelAll.Controls.Add(this.eduLabel);
            this.signUpPanelAll.Controls.Add(this.dbLabel);
            this.signUpPanelAll.Controls.Add(this.repassBox);
            this.signUpPanelAll.Controls.Add(this.repassLabel);
            this.signUpPanelAll.Controls.Add(this.passBox);
            this.signUpPanelAll.Controls.Add(this.passLabel);
            this.signUpPanelAll.Controls.Add(this.addressBox);
            this.signUpPanelAll.Controls.Add(this.addLebel);
            this.signUpPanelAll.Controls.Add(this.phoneBox);
            this.signUpPanelAll.Controls.Add(this.phoneLabel);
            this.signUpPanelAll.Controls.Add(this.emailBox);
            this.signUpPanelAll.Controls.Add(this.emailLabel);
            this.signUpPanelAll.Controls.Add(this.IdBox);
            this.signUpPanelAll.Controls.Add(this.userIdLebel);
            this.signUpPanelAll.Controls.Add(this.nameBox);
            this.signUpPanelAll.Controls.Add(this.nameLabel);
            this.signUpPanelAll.Location = new System.Drawing.Point(230, 144);
            this.signUpPanelAll.Name = "signUpPanelAll";
            this.signUpPanelAll.Size = new System.Drawing.Size(444, 490);
            this.signUpPanelAll.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(166, 267);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(264, 20);
            this.dateTimePicker1.TabIndex = 36;
            // 
            // textPath
            // 
            this.textPath.Location = new System.Drawing.Point(320, 389);
            this.textPath.Multiline = true;
            this.textPath.Name = "textPath";
            this.textPath.Size = new System.Drawing.Size(110, 30);
            this.textPath.TabIndex = 35;
            // 
            // imageButton
            // 
            this.imageButton.BackColor = System.Drawing.Color.LightSkyBlue;
            this.imageButton.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.imageButton.FontWeight = MetroFramework.MetroButtonWeight.Light;
            this.imageButton.ForeColor = System.Drawing.Color.Black;
            this.imageButton.Location = new System.Drawing.Point(320, 425);
            this.imageButton.Name = "imageButton";
            this.imageButton.Size = new System.Drawing.Size(110, 37);
            this.imageButton.TabIndex = 34;
            this.imageButton.Text = "Upload Image";
            this.imageButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.imageButton.UseCustomBackColor = true;
            this.imageButton.UseCustomForeColor = true;
            this.imageButton.UseSelectable = true;
            this.imageButton.Click += new System.EventHandler(this.imageButton_Click);
            // 
            // skillBox
            // 
            // 
            // 
            // 
            this.skillBox.CustomButton.AutoSize = true;
            this.skillBox.CustomButton.Image = null;
            this.skillBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.skillBox.CustomButton.Name = "";
            this.skillBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.skillBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.skillBox.CustomButton.TabIndex = 1;
            this.skillBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.skillBox.CustomButton.UseSelectable = true;
            this.skillBox.CustomButton.Visible = false;
            this.skillBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.skillBox.Lines = new string[0];
            this.skillBox.Location = new System.Drawing.Point(162, 347);
            this.skillBox.MaxLength = 32767;
            this.skillBox.Name = "skillBox";
            this.skillBox.PasswordChar = '\0';
            this.skillBox.PromptText = "Enter skills";
            this.skillBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.skillBox.SelectedText = "";
            this.skillBox.SelectionLength = 0;
            this.skillBox.SelectionStart = 0;
            this.skillBox.ShortcutsEnabled = true;
            this.skillBox.Size = new System.Drawing.Size(268, 30);
            this.skillBox.TabIndex = 33;
            this.skillBox.UseSelectable = true;
            this.skillBox.WaterMark = "Enter skills";
            this.skillBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.skillBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // skillLabel
            // 
            this.skillLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.skillLabel.Location = new System.Drawing.Point(26, 347);
            this.skillLabel.Name = "skillLabel";
            this.skillLabel.Size = new System.Drawing.Size(120, 30);
            this.skillLabel.TabIndex = 32;
            this.skillLabel.Text = "Skills";
            // 
            // eduBox
            // 
            // 
            // 
            // 
            this.eduBox.CustomButton.AutoSize = true;
            this.eduBox.CustomButton.Image = null;
            this.eduBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.eduBox.CustomButton.Name = "";
            this.eduBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.eduBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.eduBox.CustomButton.TabIndex = 1;
            this.eduBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.eduBox.CustomButton.UseSelectable = true;
            this.eduBox.CustomButton.Visible = false;
            this.eduBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.eduBox.Lines = new string[0];
            this.eduBox.Location = new System.Drawing.Point(162, 305);
            this.eduBox.MaxLength = 32767;
            this.eduBox.Name = "eduBox";
            this.eduBox.PasswordChar = '\0';
            this.eduBox.PromptText = "Enter education";
            this.eduBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.eduBox.SelectedText = "";
            this.eduBox.SelectionLength = 0;
            this.eduBox.SelectionStart = 0;
            this.eduBox.ShortcutsEnabled = true;
            this.eduBox.Size = new System.Drawing.Size(268, 30);
            this.eduBox.TabIndex = 31;
            this.eduBox.UseSelectable = true;
            this.eduBox.WaterMark = "Enter education";
            this.eduBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.eduBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // eduLabel
            // 
            this.eduLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.eduLabel.Location = new System.Drawing.Point(26, 305);
            this.eduLabel.Name = "eduLabel";
            this.eduLabel.Size = new System.Drawing.Size(120, 30);
            this.eduLabel.TabIndex = 30;
            this.eduLabel.Text = "Education";
            // 
            // dbLabel
            // 
            this.dbLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.dbLabel.Location = new System.Drawing.Point(23, 265);
            this.dbLabel.Name = "dbLabel";
            this.dbLabel.Size = new System.Drawing.Size(120, 30);
            this.dbLabel.TabIndex = 26;
            this.dbLabel.Text = "Date of birth";
            // 
            // repassBox
            // 
            // 
            // 
            // 
            this.repassBox.CustomButton.Image = null;
            this.repassBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.repassBox.CustomButton.Name = "";
            this.repassBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.repassBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.repassBox.CustomButton.TabIndex = 1;
            this.repassBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.repassBox.CustomButton.UseSelectable = true;
            this.repassBox.CustomButton.Visible = false;
            this.repassBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.repassBox.Lines = new string[0];
            this.repassBox.Location = new System.Drawing.Point(162, 115);
            this.repassBox.MaxLength = 32767;
            this.repassBox.Name = "repassBox";
            this.repassBox.PasswordChar = '\0';
            this.repassBox.PromptText = "Enter password again";
            this.repassBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.repassBox.SelectedText = "";
            this.repassBox.SelectionLength = 0;
            this.repassBox.SelectionStart = 0;
            this.repassBox.ShortcutsEnabled = true;
            this.repassBox.Size = new System.Drawing.Size(268, 30);
            this.repassBox.TabIndex = 23;
            this.repassBox.UseSelectable = true;
            this.repassBox.WaterMark = "Enter password again";
            this.repassBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.repassBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // repassLabel
            // 
            this.repassLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.repassLabel.Location = new System.Drawing.Point(23, 115);
            this.repassLabel.Name = "repassLabel";
            this.repassLabel.Size = new System.Drawing.Size(123, 30);
            this.repassLabel.TabIndex = 22;
            this.repassLabel.Text = "Re - Password";
            // 
            // passBox
            // 
            // 
            // 
            // 
            this.passBox.CustomButton.Image = null;
            this.passBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.passBox.CustomButton.Name = "";
            this.passBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.passBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.passBox.CustomButton.TabIndex = 1;
            this.passBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.passBox.CustomButton.UseSelectable = true;
            this.passBox.CustomButton.Visible = false;
            this.passBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.passBox.Lines = new string[0];
            this.passBox.Location = new System.Drawing.Point(162, 79);
            this.passBox.MaxLength = 32767;
            this.passBox.Name = "passBox";
            this.passBox.PasswordChar = '\0';
            this.passBox.PromptText = "Enter Password";
            this.passBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.passBox.SelectedText = "";
            this.passBox.SelectionLength = 0;
            this.passBox.SelectionStart = 0;
            this.passBox.ShortcutsEnabled = true;
            this.passBox.Size = new System.Drawing.Size(268, 30);
            this.passBox.TabIndex = 21;
            this.passBox.UseSelectable = true;
            this.passBox.WaterMark = "Enter Password";
            this.passBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.passBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // passLabel
            // 
            this.passLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.passLabel.Location = new System.Drawing.Point(23, 79);
            this.passLabel.Name = "passLabel";
            this.passLabel.Size = new System.Drawing.Size(93, 30);
            this.passLabel.TabIndex = 20;
            this.passLabel.Text = "Password";
            // 
            // addressBox
            // 
            // 
            // 
            // 
            this.addressBox.CustomButton.AutoSize = true;
            this.addressBox.CustomButton.Image = null;
            this.addressBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.addressBox.CustomButton.Name = "";
            this.addressBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.addressBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.addressBox.CustomButton.TabIndex = 1;
            this.addressBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.addressBox.CustomButton.UseSelectable = true;
            this.addressBox.CustomButton.Visible = false;
            this.addressBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.addressBox.Lines = new string[0];
            this.addressBox.Location = new System.Drawing.Point(162, 223);
            this.addressBox.MaxLength = 32767;
            this.addressBox.Name = "addressBox";
            this.addressBox.PasswordChar = '\0';
            this.addressBox.PromptText = "Enter Address";
            this.addressBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.addressBox.SelectedText = "";
            this.addressBox.SelectionLength = 0;
            this.addressBox.SelectionStart = 0;
            this.addressBox.ShortcutsEnabled = true;
            this.addressBox.Size = new System.Drawing.Size(268, 30);
            this.addressBox.TabIndex = 19;
            this.addressBox.UseSelectable = true;
            this.addressBox.WaterMark = "Enter Address";
            this.addressBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.addressBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // addLebel
            // 
            this.addLebel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.addLebel.Location = new System.Drawing.Point(23, 223);
            this.addLebel.Name = "addLebel";
            this.addLebel.Size = new System.Drawing.Size(93, 30);
            this.addLebel.TabIndex = 18;
            this.addLebel.Text = "Address";
            // 
            // phoneBox
            // 
            // 
            // 
            // 
            this.phoneBox.CustomButton.Image = null;
            this.phoneBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.phoneBox.CustomButton.Name = "";
            this.phoneBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.phoneBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.phoneBox.CustomButton.TabIndex = 1;
            this.phoneBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.phoneBox.CustomButton.UseSelectable = true;
            this.phoneBox.CustomButton.Visible = false;
            this.phoneBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.phoneBox.Lines = new string[0];
            this.phoneBox.Location = new System.Drawing.Point(162, 187);
            this.phoneBox.MaxLength = 32767;
            this.phoneBox.Name = "phoneBox";
            this.phoneBox.PasswordChar = '\0';
            this.phoneBox.PromptText = "Enter phone no";
            this.phoneBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.phoneBox.SelectedText = "";
            this.phoneBox.SelectionLength = 0;
            this.phoneBox.SelectionStart = 0;
            this.phoneBox.ShortcutsEnabled = true;
            this.phoneBox.Size = new System.Drawing.Size(268, 30);
            this.phoneBox.TabIndex = 17;
            this.phoneBox.UseSelectable = true;
            this.phoneBox.WaterMark = "Enter phone no";
            this.phoneBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.phoneBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // phoneLabel
            // 
            this.phoneLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.phoneLabel.Location = new System.Drawing.Point(23, 187);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(93, 30);
            this.phoneLabel.TabIndex = 16;
            this.phoneLabel.Text = "Phone";
            // 
            // emailBox
            // 
            // 
            // 
            // 
            this.emailBox.CustomButton.Image = null;
            this.emailBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.emailBox.CustomButton.Name = "";
            this.emailBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.emailBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.emailBox.CustomButton.TabIndex = 1;
            this.emailBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.emailBox.CustomButton.UseSelectable = true;
            this.emailBox.CustomButton.Visible = false;
            this.emailBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.emailBox.Lines = new string[0];
            this.emailBox.Location = new System.Drawing.Point(162, 151);
            this.emailBox.MaxLength = 32767;
            this.emailBox.Name = "emailBox";
            this.emailBox.PasswordChar = '\0';
            this.emailBox.PromptText = "Enter a valid email";
            this.emailBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.emailBox.SelectedText = "";
            this.emailBox.SelectionLength = 0;
            this.emailBox.SelectionStart = 0;
            this.emailBox.ShortcutsEnabled = true;
            this.emailBox.Size = new System.Drawing.Size(268, 30);
            this.emailBox.TabIndex = 15;
            this.emailBox.UseSelectable = true;
            this.emailBox.WaterMark = "Enter a valid email";
            this.emailBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.emailBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // emailLabel
            // 
            this.emailLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.emailLabel.Location = new System.Drawing.Point(23, 151);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(93, 30);
            this.emailLabel.TabIndex = 14;
            this.emailLabel.Text = "Email";
            // 
            // IdBox
            // 
            // 
            // 
            // 
            this.IdBox.CustomButton.Image = null;
            this.IdBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.IdBox.CustomButton.Name = "";
            this.IdBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.IdBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.IdBox.CustomButton.TabIndex = 1;
            this.IdBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.IdBox.CustomButton.UseSelectable = true;
            this.IdBox.CustomButton.Visible = false;
            this.IdBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.IdBox.Lines = new string[0];
            this.IdBox.Location = new System.Drawing.Point(162, 43);
            this.IdBox.MaxLength = 32767;
            this.IdBox.Name = "IdBox";
            this.IdBox.PasswordChar = '\0';
            this.IdBox.PromptText = "Enter an id";
            this.IdBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.IdBox.SelectedText = "";
            this.IdBox.SelectionLength = 0;
            this.IdBox.SelectionStart = 0;
            this.IdBox.ShortcutsEnabled = true;
            this.IdBox.Size = new System.Drawing.Size(268, 30);
            this.IdBox.TabIndex = 13;
            this.IdBox.UseSelectable = true;
            this.IdBox.WaterMark = "Enter an id";
            this.IdBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.IdBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // userIdLebel
            // 
            this.userIdLebel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.userIdLebel.Location = new System.Drawing.Point(23, 43);
            this.userIdLebel.Name = "userIdLebel";
            this.userIdLebel.Size = new System.Drawing.Size(93, 30);
            this.userIdLebel.TabIndex = 12;
            this.userIdLebel.Text = "User Id";
            // 
            // nameBox
            // 
            // 
            // 
            // 
            this.nameBox.CustomButton.Image = null;
            this.nameBox.CustomButton.Location = new System.Drawing.Point(240, 2);
            this.nameBox.CustomButton.Name = "";
            this.nameBox.CustomButton.Size = new System.Drawing.Size(25, 25);
            this.nameBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.nameBox.CustomButton.TabIndex = 1;
            this.nameBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.nameBox.CustomButton.UseSelectable = true;
            this.nameBox.CustomButton.Visible = false;
            this.nameBox.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.nameBox.Lines = new string[0];
            this.nameBox.Location = new System.Drawing.Point(162, 7);
            this.nameBox.MaxLength = 32767;
            this.nameBox.Name = "nameBox";
            this.nameBox.PasswordChar = '\0';
            this.nameBox.PromptText = "Enter your full name";
            this.nameBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.nameBox.SelectedText = "";
            this.nameBox.SelectionLength = 0;
            this.nameBox.SelectionStart = 0;
            this.nameBox.ShortcutsEnabled = true;
            this.nameBox.Size = new System.Drawing.Size(268, 30);
            this.nameBox.TabIndex = 11;
            this.nameBox.UseSelectable = true;
            this.nameBox.WaterMark = "Enter your full name";
            this.nameBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.nameBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // nameLabel
            // 
            this.nameLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.nameLabel.Location = new System.Drawing.Point(23, 7);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(93, 30);
            this.nameLabel.TabIndex = 10;
            this.nameLabel.Text = "Name";
            // 
            // signUpButton
            // 
            this.signUpButton.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.signUpButton.FontSize = MetroFramework.MetroButtonSize.Tall;
            this.signUpButton.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.signUpButton.Location = new System.Drawing.Point(557, 640);
            this.signUpButton.Name = "signUpButton";
            this.signUpButton.Size = new System.Drawing.Size(103, 37);
            this.signUpButton.TabIndex = 11;
            this.signUpButton.Text = "Sign Up";
            this.signUpButton.UseCustomBackColor = true;
            this.signUpButton.UseCustomForeColor = true;
            this.signUpButton.UseSelectable = true;
            this.signUpButton.UseStyleColors = true;
            this.signUpButton.Click += new System.EventHandler(this.signUpButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(240, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(82, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(328, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(344, 93);
            this.label1.TabIndex = 31;
            this.label1.Text = "Job Seeker Registration";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jobSeeker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 788);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.signUpButton);
            this.Controls.Add(this.signUpPanelAll);
            this.Name = "jobSeeker";
            this.Load += new System.EventHandler(this.jobSeeker_Load);
            this.signUpPanelAll.ResumeLayout(false);
            this.signUpPanelAll.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel signUpPanelAll;
        private MetroFramework.Controls.MetroTextBox repassBox;
        private MetroFramework.Controls.MetroLabel repassLabel;
        private MetroFramework.Controls.MetroTextBox passBox;
        private MetroFramework.Controls.MetroLabel passLabel;
        private MetroFramework.Controls.MetroTextBox addressBox;
        private MetroFramework.Controls.MetroLabel addLebel;
        private MetroFramework.Controls.MetroTextBox phoneBox;
        private MetroFramework.Controls.MetroLabel phoneLabel;
        private MetroFramework.Controls.MetroTextBox emailBox;
        private MetroFramework.Controls.MetroLabel emailLabel;
        private MetroFramework.Controls.MetroTextBox IdBox;
        private MetroFramework.Controls.MetroLabel userIdLebel;
        private MetroFramework.Controls.MetroTextBox nameBox;
        private MetroFramework.Controls.MetroLabel nameLabel;
        private MetroFramework.Controls.MetroLabel dbLabel;
        private MetroFramework.Controls.MetroTextBox skillBox;
        private MetroFramework.Controls.MetroLabel skillLabel;
        private MetroFramework.Controls.MetroTextBox eduBox;
        private MetroFramework.Controls.MetroLabel eduLabel;
        private MetroFramework.Controls.MetroButton signUpButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textPath;
        private MetroFramework.Controls.MetroButton imageButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}